﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PowerPinger
{
    public partial class frmTargetManager : Form
    {
        public List<string> TargetList { get; set; }

        private List<string> _targetList;

        private void UpdateForm()
        {
            if (_targetList != null)
            {
                if (_targetList.Count > 0)
                {
                    this.tbxTargets.Lines = _targetList.ToArray();  
                }
            }

        }

        public frmTargetManager()
        {
            InitializeComponent();
            UpdateForm();
        }

        public frmTargetManager(List<string> tl)
        {
            InitializeComponent();
            _targetList = tl;
            UpdateForm();
        }

        private void btnSaveTargets_Click(object sender, EventArgs e)
        {
            _targetList = new List<string>();
            if (this.tbxTargets.Lines.Count() > 0)
            {
                foreach (string line in this.tbxTargets.Lines)
                {
                    _targetList.Add(line);
                }

                this.TargetList = _targetList;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.TargetList = null;
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
